<?php
for ($i=1; $i <=12 ; $i++) {

echo "$i*$i=".$i*$i."<br>";
}
?>