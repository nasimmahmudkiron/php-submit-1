
<?php
echo "Twinkle,twinkle little star <br><br>";

$x="Twinkle";
$y="star";
echo "$x <br> $y <br><br>";

$a="Twinkle";
$b="star";
echo "$a <br> $b";

?>