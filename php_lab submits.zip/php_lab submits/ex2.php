<?php
$x=10;
$y=7;

$total=$x+$y;
echo "$total<br>";

$sub=$x-$y;
echo "$sub <br>";

$mul=$x*$y;
echo "$mul <br>";

$div=$x/$y;
echo "$div <br>";

$get=$x%$y;
echo "$get <br>";