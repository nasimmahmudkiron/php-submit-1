<?php
echo "value is now " .$variable= 8;
echo "<br>";
echo "Add 2.Value is now ".$variable+= 2;
echo "<br>";
echo "Subtract 4.Value is now ".$variable-=4;
echo "<br>";
echo "Multipy by 5.Value is now ".$variable*=5;
echo "<br>";
echo "Divided by 3.Value is now ".$variable/=3;
echo "<br>";
echo "Increment value by one.Value is now ".$variable+=1;
echo "<br>";
echo "decrement value by one.Value is now ".$variable-=1;
echo "<br>";


?>