<?php
$str="Harry";
var_dump($str);
echo "<br>";


print_r($str);
echo "<br>";

$intt=28;
var_dump($intt);
echo "<br>";

$x=NULL;
var_dump($x);
echo "<br>";

?>