<?php
$around="around";
echo 'What goes '.$around.', comes.'. $around;
?>